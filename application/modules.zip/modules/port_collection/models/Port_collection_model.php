<?php
    class Port_collection_model 
    {
        
    }

?>