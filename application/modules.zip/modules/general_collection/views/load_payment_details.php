<h4 class="title-header"> Payment Details</h4>
<div class="body">
    <table style="width: 100%; border: 1px solid black;">
        <tr>
            <th colspan="1"></th>
            <th colspan="2"></th>                               
        </tr>
        <tr>
            <td><label>Name:</label><input type="text" class="form-control input-sm" style="width: 40%"></td> 
            <td><label>Total:</label><h4>0.00</h4></td>                                                                                           
            <td></td>          
        </tr>
        <tr>
            <td><label>Date:</label><input type="text" class="form-control input-sm date_paid" style="width: 40%"></td>
            <td><button class="btn btn-success btn-sm" id="save"><i class="fa fa-plus-square"></i> Save</button></td>
            <td></td>
        </tr>
    </table>                        
</div>