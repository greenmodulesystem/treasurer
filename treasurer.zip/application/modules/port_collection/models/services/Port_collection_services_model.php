<?php
    class Port_collection_services_model extends CI_Model 
    {
        
    }

?>