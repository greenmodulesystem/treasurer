<style>
    .input-data-info{
        border-style: none none none none;
        margin: 0px;
        padding: 0px;
        outline: none;
        background-color: transparent;
        text-align: left;
    }
</style>
<!-- Marriage div input data -->
<div class="box-body" id="fill-out-form">
    <div class="box-body">
        <p style="color: red; font: bold 15px Bookman Old Style;">Please fill out the details below:</p>
    </div>
    <div id="certificate-form">    
        <div class="row"> 
            <div class="box-body">
                <div class="box-body">
                    <table width="100%">
                        <tr><td style="text-align: center; font-size: 18px;"> City of Cadiz </td></tr>
                        <tr><td style="text-align: center; font-size: 17px;"> Local Civil Registrar Office </td></tr>
                        <tr><td style="text-align: center;; font-size: 15px;"> Application for Marriage License </td></tr>                            
                    </table>

                    <table style="margin-top: 25px;">
                        <tbody>
                            <tr>
                                <td> Complete Name of Recepient </td>
                                <td>&nbsp;&nbsp; <input class="input-data-info" placeholder="Complete Name"> </td>
                                <td> Purpose of Transaction </td>
                                <td>&nbsp;&nbsp; <input class="input-data-info" placeholder="Purpose of Transaction"> </td>
                            </tr>                         
                            <tr>
                                <td> Place of Issue </td>
                                <td><input class="input-data-info" placeholder="Place of Issue"></td>
                            </tr>               
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>