<div id="certificate-form">
CERTIFICATE TEMPLATE HERE
<?php
    // echo json_encode($details);
?>
</div>
