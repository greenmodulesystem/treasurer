
 <table class="table" style="font-size:12px;">
    <thead >
        <tr>
            <th>OR Type</th>
            <th>Stub No</th>
            <th>Start OR</th>
            <th>End OR</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody id="stabs-lists">

    </tbody>
</table>