<?php
$this->load->view($content);
?>