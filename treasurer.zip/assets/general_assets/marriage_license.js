$(document).on('click', '#clicked-fill-out-form', function(){
    document.getElementById('fill-out-form').style.display = "block";
});